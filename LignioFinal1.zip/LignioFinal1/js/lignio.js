$("#hamburger_button").click(function () {
  if($('body').hasClass("is-drawer-open")){
    $("#logout-border").css("margin-left","0");
    $(".logout-text").css("margin-left","13px");
    $('.timeline').removeClass("col-md-offset-0");
    $('.timeline').removeClass("col-md-11");
    $('.timeline').addClass("col-md-offset-0");
    $('.timeline').addClass("col-md-12");
  }
  else{
    $("#logout-border").css("margin-left","30%");
    $('.timeline').addClass("col-md-offset-0");
    $('.timeline').addClass("col-md-11");
    $('.timeline').removeClass("col-md-offset-0");
    $('.timeline').removeClass("col-md-12");
  }
});



var width=$(window).width();
var a =1;
$("#booking_one_center").mouseenter(function () {
  if(width < 768){
    $("#booking_one_center").css("margin-left","-43px");
    $("#padding_right_view_1").css("margin-left","-15px");
    $("#view_button_one").css("margin","0");
  }
  else{
    $("#booking_one_center").css("margin-left","0");
    $("#padding_right_view_1").css("margin-left","15px");
  }
    $("#booking_one_left").css("display","block");
    $("#booking_one_right").css("display","block");
    $("#view_button_one").css("display","block");
    $("#booking_one").css("box-shadow","0 0 30px 1px rgba(0, 0, 0, 0.07), 0 5px 5px -5px rgba(0, 0, 0, 0.07), 0 5px 5px 0 rgba(0, 0, 0, 0.07)");
});
$("#booking_one_center").mouseleave(function () {
  if(width < 768){
    $("#booking_one_center").css("margin-left","30px");
    $("#padding_right_view_1").css("margin-left","5px");
  }
  else {
    $("#booking_one_center").css("margin-left","62px");
    $("#padding_right_view_1").css("margin-left","-70px");
  }
    $("#booking_one_left").css("display","none");
    $("#booking_one_right").css("display","none");
    $("#view_button_one").css("display","none");
    $("#booking_one").css("box-shadow","none");
});
$("#booking_two_center").mouseenter(function () {
  if(width < 768){
    $("#booking_two_center").css("margin-left","-43px");
    $("#padding_right_view_2").css("margin-left","-15px");
    $("#view_button_two").css("margin","0");
  }
  else{
    $("#booking_two_center").css("margin-left","0");
    $("#padding_right_view_2").css("margin-left","15px");
  }
  $("#booking_two_left").css("display","block");
  $("#booking_two_right").css("display","block");
  $("#view_button_two").css("display","block");
  $("#booking_two").css("box-shadow","0 0 30px 1px rgba(0, 0, 0, 0.07), 0 5px 5px -5px rgba(0, 0, 0, 0.07), 0 5px 5px 0 rgba(0, 0, 0, 0.07)");
});
$("#booking_two_center").mouseleave(function () {
  if(width < 768){
    $("#booking_two_center").css("margin-left","30px");
    $("#padding_right_view_2").css("margin-left","5px");
  }
  else {
    $("#booking_two_center").css("margin-left","62px");
    $("#padding_right_view_2").css("margin-left","-70px");
  }
  $("#booking_two_left").css("display","none");
  $("#booking_two_right").css("display","none");
  $("#view_button_two").css("display","none");
  $("#booking_two").css("box-shadow","none");
});
$("#booking_three_center").mouseenter(function () {
  if(width < 768){
    $("#booking_three_center").css("margin-left","-43px");
    $("#padding_right_view_3").css("margin-left","-15px");
    $("#view_button_three").css("margin","0");
  }
  else{
    $("#booking_three_center").css("margin-left","0");
    $("#padding_right_view_3").css("margin-left","15px");
  }
  $("#booking_three_left").css("display","block");
  $("#booking_three_right").css("display","block");
  $("#view_button_three").css("display","block");
  $("#booking_three").css("box-shadow","0 0 30px 1px rgba(0, 0, 0, 0.07), 0 5px 5px -5px rgba(0, 0, 0, 0.07), 0 5px 5px 0 rgba(0, 0, 0, 0.07)");
});
$("#booking_three_center").mouseleave(function () {
  if(width < 768){
    $("#booking_three_center").css("margin-left","30px");
    $("#padding_right_view_3").css("margin-left","5px");
  }
  else {
    $("#booking_three_center").css("margin-left","62px");
    $("#padding_right_view_3").css("margin-left","-70px");
  }
  $("#booking_three_left").css("display","none");
  $("#booking_three_right").css("display","none");
  $("#view_button_three").css("display","none");
  $("#booking_three").css("box-shadow","none");
});
$("#booking_four_center").mouseenter(function () {
  if (width < 768) {
    $("#booking_four_center").css("margin-left", "-43px");
    $("#padding_right_view_4").css("margin-left", "-15px");
    $("#view_button_four").css("margin", "0");
  }
  else {
    $("#booking_four_center").css("margin-left", "0");
    $("#padding_right_view_4").css("margin-left", "15px");
  }
  $("#booking_four_left").css("display", "block");
  $("#booking_four_right").css("display", "block");
  $("#view_button_four").css("display", "block");
  $("#booking_four").css("box-shadow", "0 0 30px 1px rgba(0, 0, 0, 0.07), 0 5px 5px -5px rgba(0, 0, 0, 0.07), 0 5px 5px 0 rgba(0, 0, 0, 0.07)");
});
$("#booking_four_center").mouseleave(function () {
  if(width < 768){
    $("#booking_four_center").css("margin-left","30px");
    $("#padding_right_view_4").css("margin-left","5px");
  }
  else {
    $("#booking_four_center").css("margin-left","62px");
    $("#padding_right_view_4").css("margin-left","-70px");
  }
  $("#booking_four_left").css("display","none");
  $("#booking_four_right").css("display","none");
  $("#view_button_four").css("display","none");
  $("#booking_four").css("box-shadow","none");
});
$("#booking_five_center").mouseenter(function () {
  if(width < 768){
    $("#booking_five_center").css("margin-left","-43px");
    $("#padding_right_view_5").css("margin-left","-15px");
    $("#view_button_five").css("margin","0");
  }
  else{
    $("#booking_five_center").css("margin-left","0");
    $("#padding_right_view_5").css("margin-left","15px");
  }

  $("#booking_five_left").css("display","block");
  $("#booking_five_right").css("display","block");
  $("#view_button_five").css("display","block");
  $("#booking_five").css("box-shadow","0 0 30px 1px rgba(0, 0, 0, 0.07), 0 5px 5px -5px rgba(0, 0, 0, 0.07), 0 5px 5px 0 rgba(0, 0, 0, 0.07)");
});
$("#booking_five_center").mouseleave(function () {
  if(width < 768){
    $("#booking_five_center").css("margin-left","30px");
    $("#padding_right_view_5").css("margin-left","5px");
  }
  else {
    $("#booking_five_center").css("margin-left","62px");
    $("#padding_right_view_5").css("margin-left","-70px");
  }
  $("#booking_five_left").css("display","none");
  $("#booking_five_right").css("display","none");
  $("#view_button_five").css("display","none");
  $("#booking_five").css("box-shadow","none");
});
$("#booking_six_center").mouseenter(function () {
  if(width < 768){
    $("#booking_six_center").css("margin-left","-43px");
    $("#padding_right_view_6").css("margin-left","-15px");
    $("#view_button_six").css("margin","0");
  }
  else{
    $("#booking_six_center").css("margin-left","0");
    $("#padding_right_view_6").css("margin-left","15px");
  }

  $("#booking_six_left").css("display","block");
  $("#booking_six_right").css("display","block");
  $("#view_button_six").css("display","block");
  $("#booking_six").css("box-shadow","0 0 30px 1px rgba(0, 0, 0, 0.07), 0 5px 5px -5px rgba(0, 0, 0, 0.07), 0 5px 5px 0 rgba(0, 0, 0, 0.07)");
});
$("#booking_six_center").mouseleave(function () {
  if(width < 768){
    $("#booking_six_center").css("margin-left","30px");
    $("#padding_right_view_6").css("margin-left","5px");
  }
  else {
    $("#booking_six_center").css("margin-left","62px");
    $("#padding_right_view_6").css("margin-left","-70px");
  }
  $("#booking_six_left").css("display","none");
  $("#booking_six_right").css("display","none");
  $("#view_button_six").css("display","none");
  $("#booking_six").css("box-shadow","none");
});
$("#booking_seven_center").mouseenter(function () {
  if(width < 768){
    $("#booking_seven_center").css("margin-left","-43px");
    $("#padding_right_view_7").css("margin-left","-15px");
    $("#view_button_seven").css("margin","0");
  }
  else{
    $("#booking_seven_center").css("margin-left","0");
    $("#padding_right_view_7").css("margin-left","15px");
  }

  $("#booking_seven_left").css("display","block");
  $("#booking_seven_right").css("display","block");
  $("#view_button_seven").css("display","block");
  $("#booking_seven").css("box-shadow","0 0 30px 1px rgba(0, 0, 0, 0.07), 0 5px 5px -5px rgba(0, 0, 0, 0.07), 0 5px 5px 0 rgba(0, 0, 0, 0.07)");
});
$("#booking_seven_center").mouseleave(function () {
  if(width < 768){
    $("#booking_seven_center").css("margin-left","30px");
    $("#padding_right_view_7").css("margin-left","5px");
  }
  else {
    $("#booking_seven_center").css("margin-left","62px");
    $("#padding_right_view_7").css("margin-left","-70px");
  }
  $("#booking_seven_left").css("display","none");
  $("#booking_seven_right").css("display","none");
  $("#view_button_seven").css("display","none");
  $("#booking_seven").css("box-shadow","none");
});
$("#copy_down_arrow_logo").click(function () {
    $("#copy_down_arrow_logo").toggleClass("rotate180");
    $("#expand-1").css("background-color","#fafafa");
    $("#expand-1").css("box-shadow","1px -1px rgba(0, 0, 0, 0.07), 3px 3px 20px -5px rgba(0, 0, 0, 0.07)");
});
$("#trending_article_body_5").mouseenter(function () {
    $("#trending_article_body_5").css("z-index","10");
    $("#trending_article_body_5").css("box-shadow","1px -1px rgba(0, 0, 0, 0.07), 3px 3px 20px -5px rgba(0, 0, 0, 0.07)");
    $("#trending_article_inner_right_5").css('display','block');
    $("#trending_article_inner_left_5").css('display','block');

  if(width > 960){
    $(".copy_trending_articles_body_items_centre").css("padding","0 61px");
    $("#health_alert_data_right_5").css("padding","0 4px");
  }
  else{
    $(".copy_trending_articles_body_items_centre").css("padding","0");
    $("#health_alert_data_right_5").css("padding","0 22px");
  }
});
$("#trending_article_body_5").mouseleave(function () {
    $("#trending_article_body_5").css("z-index","0");
    $("#trending_article_body_5").css("box-shadow","none");
    $("#trending_article_inner_right_5").css('display','none');
    $("#trending_article_inner_left_5").css('display','none');
    $("#health_alert_data_right_5").css("padding","0");
    $(".copy_trending_articles_body_items_centre").css("padding","0");
});
$("#trending_article_body_4").mouseenter(function () {
    $("#trending_article_body_4").css("z-index","10");
    $("#trending_article_body_4").css("box-shadow","1px -1px rgba(0, 0, 0, 0.07), 3px 3px 20px -5px rgba(0, 0, 0, 0.07)");
    $("#trending_article_inner_right_4").css('display','block');
    $("#trending_article_inner_left_4").css('display','block');

    if(width > 960){
      $(".copy_trending_articles_body_items_centre").css("padding","0 61px");
      $("#health_alert_data_right_4").css("padding","0 4px");
    }
    else{
      $(".copy_trending_articles_body_items_centre").css("padding","0");
      $("#health_alert_data_right_4").css("padding","0 22px");
    }

});
$("#trending_article_body_4").mouseleave(function () {
    $("#trending_article_body_4").css("z-index","0");
    $("#trending_article_body_4").css("box-shadow","none");
    $("#trending_article_inner_right_4").css('display','none');
    $("#trending_article_inner_left_4").css('display','none');
    $("#health_alert_data_right_4").css("padding","0");
    $(".copy_trending_articles_body_items_centre").css("padding","0");
});
$("#trending_article_body_3").mouseenter(function () {
    $("#trending_article_body_3").css("z-index","10");
    $("#trending_article_body_3").css("box-shadow","1px -1px rgba(0, 0, 0, 0.07), 3px 3px 20px -5px rgba(0, 0, 0, 0.07)");
    $("#trending_article_inner_right_3").css('display','block');
    $("#trending_article_inner_left_3").css('display','block');

  if(width > 960){
    $(".copy_trending_articles_body_items_centre").css("padding","0 61px");
    $("#health_alert_data_right_3").css("padding","0 4px");
  }
  else{
    $(".copy_trending_articles_body_items_centre").css("padding","0");
    $("#health_alert_data_right_3").css("padding","0 22px");
  }
});
$("#trending_article_body_3").mouseleave(function () {
    $("#trending_article_body_3").css("z-index","0");
    $("#trending_article_body_3").css("box-shadow","none");
    $("#trending_article_inner_right_3").css('display','none');
    $("#trending_article_inner_left_3").css('display','none');
    $("#health_alert_data_right_3").css("padding","0");
    $(".copy_trending_articles_body_items_centre").css("padding","0");
});
$("#trending_article_body_2").mouseenter(function () {
    $("#trending_article_body_2").css("z-index","10");
    $("#trending_article_body_2").css("box-shadow","1px -1px rgba(0, 0, 0, 0.07), 3px 3px 20px -5px rgba(0, 0, 0, 0.07)");
    $("#trending_article_inner_right_2").css('display','block');
    $("#trending_article_inner_left_2").css('display','block');
    $("#health_alert_data_right_2").css("padding","0 4px");
  if(width > 960){
    $(".copy_trending_articles_body_items_centre").css("padding","0 61px");
    $("#health_alert_data_right_2").css("padding","0 4px");
  }
  else{
    $(".copy_trending_articles_body_items_centre").css("padding","0");
    $("#health_alert_data_right_2").css("padding","0 22px");
  }
});
$("#trending_article_body_2").mouseleave(function () {
    $("#trending_article_body_2").css("z-index","0");
    $("#trending_article_body_2").css("box-shadow","none");
    $("#trending_article_inner_right_2").css('display','none');
    $("#trending_article_inner_left_2").css('display','none');
    $("#health_alert_data_right_2").css("padding","0");
    $(".copy_trending_articles_body_items_centre").css("padding","0");
});
$("#trending_article_body_1").mouseenter(function () {
    $("#trending_article_body_1").css("z-index","10");
    $("#trending_article_body_1").css("box-shadow","0 0 12px 1px rgba(0, 0, 0, 0.07)");
    $("#trending_article_inner_right_1").css('display','block');
    $("#trending_article_inner_left_1").css('display','block');

  if(width > 960){
    $(".copy_trending_articles_body_items_centre").css("padding","0 61px");
    $("#health_alert_data_right_1").css("padding","0 4px");
  }
  else{
    $(".copy_trending_articles_body_items_centre").css("padding","0");
    $("#health_alert_data_right_1").css("padding","0 22px");
  }
});
$("#trending_article_body_1").mouseleave(function () {
    $("#trending_article_body_1").css("z-index","0");
    $("#trending_article_body_1").css("box-shadow","none");
    $("#trending_article_inner_right_1").css('display','none');
    $("#trending_article_inner_left_1").css('display','none');
    $("#health_alert_data_right_1").css("padding","0");
    $(".copy_trending_articles_body_items_centre").css("padding","0");
});
$("#timeline-drawer").mouseenter(function () {
    if(a==1){
        $(".icon-pack").css("background-color","#37b0ff");
        $(".icon-pack-position").css("color","#fafafa");
        a=1;
    }
});
$("#timeline-drawer").mouseleave(function () {
    if(a==1){
        $(".icon-pack").css("background-color","#ececec");
        $(".icon-pack-position").css("color","#000");
        a=1;
    }
});
$("#timeline-drawer").click(function () {
    if(a==1){
        $(".icon-pack").css("background-color","#37b0ff");
        $(".icon-pack-position").css("color","#fafafa");
        a=2;
    }
});
$("#timeline-drawer").blur(function () {
    $(".icon-pack").css("background-color","#ececec");
    $(".icon-pack-position").css("color","#000");
    // $("#mybooking").css("background-color","#00c6ff");
    a=1;
});
$(".copy_health_alerts_data_1").mouseenter(function () {
    $(".border-left-color_1").css("background-color","#00c6ff");
});
$(".copy_health_alerts_data_2").mouseenter(function () {
    $(".border-left-color_2").css("background-color","#00c6ff");

});$(".copy_health_alerts_data_3").mouseenter(function () {
    $(".border-left-color_3").css("background-color","#00c6ff");

});$(".copy_health_alerts_data_4").mouseenter(function () {
    $(".border-left-color_4").css("background-color","#00c6ff");

});$(".copy_health_alerts_data_5").mouseenter(function () {
    $(".border-left-color_5").css("background-color","#00c6ff");

});$(".copy_health_alerts_data_6").mouseenter(function () {
    $(".border-left-color_6").css("background-color","#00c6ff");

});
$(".copy_health_alerts_data_1").mouseleave(function () {
    $(".border-left-color_1").css("background-color","#fafafa");
});
$(".copy_health_alerts_data_2").mouseleave(function () {
    $(".border-left-color_2").css("background-color","#fafafa");
});
$(".copy_health_alerts_data_3").mouseleave(function () {
    $(".border-left-color_3").css("background-color","#fafafa");
});
$(".copy_health_alerts_data_4").mouseleave(function () {
    $(".border-left-color_4").css("background-color","#fafafa");
});
$(".copy_health_alerts_data_5").mouseleave(function () {
    $(".border-left-color_5").css("background-color","#fafafa");
});
$(".copy_health_alerts_data_6").mouseleave(function () {
    $(".border-left-color_6").css("background-color","#fafafa");
});
$("#trending_1").mouseenter(function () {
    $(".trending_articles_picture_bottom_1").css("background-color","#00c6ff");

});
$("#trending_1").mouseleave(function () {
    $(".trending_articles_picture_bottom_1").css("background-color","#fafafa");
});
$("#trending_2").mouseenter(function () {
    $(".trending_articles_picture_bottom_2").css("background-color","#00c6ff");

});
$("#trending_2").mouseleave(function () {
    $(".trending_articles_picture_bottom_2").css("background-color","#fafafa");
});
$("#trending_3").mouseenter(function () {
    $(".trending_articles_picture_bottom_3").css("background-color","#00c6ff");

});
$("#trending_3").mouseleave(function () {
    $(".trending_articles_picture_bottom_3").css("background-color","#fafafa");
});
$("#trending_4").mouseenter(function () {
    $(".trending_articles_picture_bottom_4").css("background-color","#00c6ff");

});
$("#trending_4").mouseleave(function () {
    $(".trending_articles_picture_bottom_4").css("background-color","#fafafa");
});
$("#trending_5").mouseenter(function () {
    $(".trending_articles_picture_bottom_5").css("background-color","#00c6ff");

});
$("#trending_5").mouseleave(function () {
    $(".trending_articles_picture_bottom_5").css("background-color","#fafafa");
});
$("#payment_one").mouseenter(function () {
  $("#payment_one_left").css("display","block");
  $("#payment_one_right").css("display","block");
  $("#p_one").css("background-color","#ffffff");
  $("#p_one > .img_style").css("width","18px");
  $("#payment_one_center").css("margin-left","1px");
  $(".img_style_1").css("filter","grayscale(0%)");
});
$("#payment_one").mouseleave(function () {
  $("#payment_one_left").css("display","none");
  $("#payment_one_right").css("display","none");
  $("#p_one").css("background-color","#f4f4f4");
  $("#p_one > .img_style").css("width","33%");
  $("#payment_one_center").css("margin-left","20px");
  $(".img_style_1").css("filter","grayscale(100%)");
});
$("#payment_two").mouseenter(function () {
  $("#payment_two_left").css("display","block");
  $("#payment_two_right").css("display","block");
  $("#p_two").css("background-color","#ffffff");
  $("#p_two > .img_style").css("width","18px");
  $("#payment_two_center").css("margin-left","1px");
  $(".img_style_2").css("filter","grayscale(0%)");
});
$("#payment_two").mouseleave(function () {
  $("#payment_two_left").css("display","none");
  $("#payment_two_right").css("display","none");
  $("#p_two").css("background-color","#f4f4f4");
  $("#p_two > .img_style").css("width","33%");
  $("#payment_two_center").css("margin-left","20px");
  $(".img_style_2").css("filter","grayscale(100%)");
});
$("#payment_three").mouseenter(function () {
  $("#payment_three_left").css("display","block");
  $("#payment_three_right").css("display","block");
  $("#p_three").css("background-color","#ffffff");
  $("#p_three > .img_style").css("width","18px");
  $("#payment_three_center").css("margin-left","1px");
  $(".img_style_3").css("filter","grayscale(0%)");
});
$("#payment_three").mouseleave(function () {
  $("#payment_three_left").css("display","none");
  $("#payment_three_right").css("display","none");
  $("#p_three").css("background-color","#f4f4f4");
  $("#p_three > .img_style").css("width","33%");
  $("#payment_three_center").css("margin-left","20px");
  $(".img_style_3").css("filter","grayscale(100%)");
});
$("#payment_four").mouseenter(function () {
  $("#payment_four_left").css("display","block");
  $("#payment_four_right").css("display","block");
  $("#p_four").css("background-color","#ffffff");
  $("#p_four > .img_style").css("width","18px");
  $("#payment_four_center").css("margin-left","1px");
  $(".img_style_4").css("filter","grayscale(0%)");
});
$("#payment_four").mouseleave(function () {
  $("#payment_four_left").css("display","none");
  $("#payment_four_right").css("display","none");
  $("#p_four").css("background-color","#f4f4f4");
  $("#p_four > .img_style").css("width","33%");
  $("#payment_four_center").css("margin-left","20px");
  $(".img_style_4").css("filter","grayscale(100%)");
});
$("#payment_five").mouseenter(function () {
  $("#payment_five_left").css("display","block");
  $("#payment_five_right").css("display","block");
  $("#p_five").css("background-color","#ffffff");
  $("#p_five > .img_style").css("width","18px");
  $("#payment_five_center").css("margin-left","1px");
  $(".img_style_5").css("filter","grayscale(0%)");
});
$("#payment_five").mouseleave(function () {
  $("#payment_five_left").css("display","none");
  $("#payment_five_right").css("display","none");
  $("#p_five").css("background-color","#f4f4f4");
  $("#p_five > .img_style").css("width","33%");
  $("#payment_five_center").css("margin-left","20px");
  $(".img_style_5").css("filter","grayscale(100%)");
});
$("#payment_six").mouseenter(function () {
  $("#payment_six_left").css("display","block");
  $("#payment_six_right").css("display","block");
  $("#p_six").css("background-color","#ffffff");
  $("#p_six > .img_style").css("width","18px");
  $("#payment_six_center").css("margin-left","1px");
  $(".img_style_6").css("filter","grayscale(0%)");
});
$("#payment_six").mouseleave(function () {
  $("#payment_six_left").css("display","none");
  $("#payment_six_right").css("display","none");
  $("#p_six").css("background-color","#f4f4f4");
  $("#p_six > .img_style").css("width","33%");
  $("#payment_six_center").css("margin-left","20px");
  $(".img_style_6").css("filter","grayscale(100%)");
});
var b = 1;
$("#mybooking").click(function() {
  $('html, body').animate({
    scrollTop: $("#demo_space_booking").offset().top
  }, 1000);
});
$("#mypayment").click(function() {
  $('html, body').animate({
    scrollTop: $("#demo_space_payment").offset().top
  }, 1000);
});
$("#mytest").click(function() {
  $('html, body').animate({
    scrollTop: $("#demo_space_test").offset().top
  }, 1000);
});
$("#timeline-drawer").click(function() {
  $('html, body').animate({
    scrollTop: $("#app").offset().top
  }, 1000);
});