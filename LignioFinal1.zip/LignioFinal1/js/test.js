$(document).ready(function(){
	   $(window).bind('scroll', function() {
	   var navHeight = $( window ).height()-50;
			 if ($(window).scrollTop() > navHeight) {
				 $('header').css('opacity','1');
			 }
			 else {
				 $('header').css('opacity','0');
			 }
		});
	});
// $(window).scroll(function() {
//    if($(window).scrollTop() + $(window).height() < 800) {
//        $('html, body').animate({scrollTop: $("#slide1").offset().top}, 1000);
//    }
//    if($(window).scrollTop() + $(window).height() > 800 ){

//    }
// });
$(window).scroll(function() {
  var scroll = $(window).scrollTop();
	$(".zoom-me").css({
		opacity: (1 - scroll/700),
		top: -(scroll/10)  + "%",
		//Blur suggestion from @janwagner: https://codepen.io/janwagner/ in comments
		"-webkit-filter": "blur(" + (scroll/200) + "px)",
		filter: "blur(" + (scroll/200) + "px)"
	});
});

//Animate a dot from top to bottom

function beeLeft() {
  $("#dot").css("opacity","0");
  $("#dot").animate({top: "-=80"}, 200, "swing", beeRight);

}
function beeRight() {
  $("#dot").animate({top: "+=80"}, 1000, "swing", beeLeft);
  $("#dot").css("opacity","1");
}

beeRight();

//Image Slider
$(".next").click(function(){
	if($("#one").hasClass("active")){
		$("#one").animate({left: '-100%'},'slow');
		$("#one").removeClass("active");
		$("#two").delay(1000).animate({left: '0%'},'slow');
		$("#tab1").removeClass('tab-color');
		$('#slide1').fadeOut(0).removeClass('active-text');
		$('#slide2').addClass('active-text').fadeIn(2000);
		$("#tab2").addClass('tab-color');
		$("#two").addClass('active');
		return;
	}
	if($("#two").hasClass("active")){
		$("#two").animate({left: '-100%'},'slow');
		$("#two").removeClass("active");
		$("#three").delay(1000).animate({left: '0%'},'slow');
		$("#tab2").removeClass('tab-color');
		$('#slide2').fadeOut(0).removeClass('active-text');
		$('#slide3').addClass('active-text').fadeIn(2000);
		$("#tab3").addClass('tab-color');
		$("#three").addClass("active");
		return;
	}
	if($("#three").hasClass("active")){
		$("#three").animate({left: '-100%'},'slow');
		$("#three").removeClass("active");
		$("#four").delay(1000).animate({left: '0%'},'slow');
		$("#tab3").removeClass('tab-color');
		$('#slide3').fadeOut(0).removeClass('active-text');
		$('#slide4').addClass('active-text').fadeIn(2000);
		$("#tab4").addClass('tab-color');
		$("#four").addClass("active");
		return;
	}
	if($("#four").hasClass("active")){
		$("#four").animate({left: '-100%'},'slow');
		$("#four").removeClass("active");
		$("#one").delay(1000).animate({left: '0%'},'slow');
		$("#tab4").removeClass('tab-color');
		$('#slide4').fadeOut(0).removeClass('active-text');
		$('#slide1').addClass('active-text').fadeIn(2000);
		$("#tab1").addClass('tab-color');
		$("#one").addClass("active");
		return;
	}

});
$(".prev").click(function(){
	if($("#one").hasClass("active")){
		$("#one").animate({left: '-100%'},'slow');
		$("#one").removeClass("active");
		$("#tab1").removeClass('tab-color');
		$("#four").delay(1000).animate({left: '0%'},'slow');
		$('#slide1').fadeOut(0).removeClass('active-text');
		$('#slide4').addClass('active-text').fadeIn(2000);
		$("#tab4").addClass('tab-color');
		$("#four").addClass('active');
		return;
	}
	if($("#two").hasClass("active")){
		$("#two").animate({left: '-100%'},'slow');
		$("#two").removeClass("active");
		$("#tab2").removeClass('tab-color');
		$("#one").delay(1000).animate({left: '0%'},'slow');
		$('#slide2').fadeOut(0).removeClass('active-text');
		$('#slide1').addClass('active-text').fadeIn(2000);
		$("#tab1").addClass('tab-color');
		$("#one").addClass("active");
		return;
	}
	if($("#three").hasClass("active")){
		$("#three").animate({left: '-100%'},'slow');
		$("#three").removeClass("active");
		$("#tab3").removeClass('tab-color');
		$("#two").delay(1000).animate({left: '0%'},'slow');
		$('#slide3').fadeOut(0).removeClass('active-text');
		$('#slide2').addClass('active-text').fadeIn(2000);
		$("#tab2").addClass('tab-color');
		$("#two").addClass("active");
		return;
	}
	if($("#four").hasClass("active")){
		$("#four").animate({left: '-100%'},'slow');
		$("#four").removeClass("active");
		$("#tab4").removeClass('tab-color');
		$("#three").delay(1000).animate({left: '0%'},'slow');
		$('#slide4').fadeOut(0).removeClass('active-text');
		$('#slide3').addClass('active-text').fadeIn(2000);
		$("#tab3").addClass('tab-color');
		$("#three").addClass("active");
		return;
	}
});
function myFunction() {
    var x = document.getElementById("myInput");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
function myFunction2() {
    var x = document.getElementById("myInput2");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
$("#a").click(function(){
	$("#myModal").modal("hide");
});
$("#b").click(function(){
	$("#myModal2").modal("hide");
});

